<?php $__env->startSection('navbar-desktop'); ?>

<!-- Desktop Navbar Begins --- -->        
        <div class="grid-item navi">
            <div class="top-bar">
                <a href="tel:+4407741681645"><i class="fa-solid fa-phone-volume black" id="top-bar-m"></i> Call: 07741681645</a>
            </div>    
            <nav class="navigation-bar">
                <div class="logo">
                    <img src="/images/logo/logo_square-removebg1.png">
                </div>
                <a href="#" class="nav-toggle"><i class="fa-solid fa-bars"></i></a>
                 <div class="navigation-links">
                    <ul class="nav-ul">
                        <li><a href="/">Home</a></li>

                        

                        <li><a href="<?php echo Request::is('/') ? '' : url('/'); ?>#Services">Services</a></li>
                        <li><a href="<?php echo Request::is('/') ? '' : url('/'); ?>#About">About</a></li>
                        <li><a href="<?php echo Request::is('/') ? '' : url('/'); ?>#Contact">Contact</a></li>
                        <li><a href="/blog">Blog</a></li>

                        <?php if(Auth::check()): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-or-editor-only')): ?>
                        <li><a href="/dashboard">Admin</a></li>
                        <?php endif; ?>
                        <?php endif; ?>
                                    

                    </ul>    
                </div>     
                <div class="telephone">
                    <form action="tel:+4407741681645" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <button class="button-large" id="telephone"><i class="fa-solid fa-phone-volume black"></i> Call: 07741681645 </button>
                    </form>
                </div>
            </nav>
            
        </div>
<!-- Desktop Navbar Ends --- -->

<?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/inc/navbar-desktop.blade.php ENDPATH**/ ?>
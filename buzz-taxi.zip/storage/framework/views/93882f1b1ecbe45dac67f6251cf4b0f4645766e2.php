<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/dashboard.css')); ?>">
    <meta name="robots" content="noindex, nofollow"/>
    <title>Admin Panel</title>
</head>
<body>

    <div class="sidebar">
        <ul>
            <li><a href="/dashbord/posts">Posts</a></li>
            <li><a href="/dashboard/bookings">Bookings</a></li>
            <li><a href="/dashboard/users">Users</a></li>
            <li><a href="/">To Website</a></li>
            <li>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="logout" type="submit">Log Out</button>
                </form>            
            </li>
        </ul>
    </div>

    <div class="main">
        <h2>Welcome <?php echo e($user->name); ?></h2>
        <h4>Your role is: <?php echo e($user->role->role); ?></h4>
    
        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    
    </div>


</body>
</html>
<?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/dashboard.blade.php ENDPATH**/ ?>
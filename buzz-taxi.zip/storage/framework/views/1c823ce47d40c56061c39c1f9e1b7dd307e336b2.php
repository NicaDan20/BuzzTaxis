<h2>Hello!</h2>
You have received a car booking from: <strong><?php echo e($name); ?></strong>
<br>
Here are the details:
<br>
<b>Name:</b> <?php echo e($name); ?>

<br>
<b>Email:</b> <?php echo e($email); ?>

<br>
<b>Phone Number:</b> <?php echo e($phone); ?>

<br>
<b>From:</b> <?php echo e($pickup); ?>

<br>
<b>To:</b> <?php echo e($destination); ?>

<br>
<b>Number of people:</b> <?php echo e($nr_people); ?>

<br>
<b>Date:</b> <?php echo e($date); ?>


<?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/booking-notification.blade.php ENDPATH**/ ?>
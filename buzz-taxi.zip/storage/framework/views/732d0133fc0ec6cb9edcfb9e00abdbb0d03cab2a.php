<div class="js-cookie-consent cookie-consent">

    <span class="cookie-consent__message">
        <?php echo trans('cookieConsent::texts.message'); ?>

    </span>

    <button class="js-cookie-consent-agree cookie-consent__agree">
        <?php echo e(trans('cookieConsent::texts.agree')); ?>

    </button>

</div>
<?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\vendor\spatie\laravel-cookie-consent\src/../resources/views/dialogContents.blade.php ENDPATH**/ ?>
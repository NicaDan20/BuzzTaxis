

<?php $__env->startSection('title'); ?>
<?php echo e('Buzz Taxis - ' . $post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
<?php echo strip_tags($post->description); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="blog-main-content">
    <div class="blog-title-header">
        <h1><?php echo e($post->title); ?></h1>
    </div>

    <div class="blog-image-container">
        <img class="preview-image blog-image full-screen" src="\<?php echo e($post->image_path); ?>" alt="Blog Image">
    </div>

    <div class="blog-post-text">
        <?php echo $post->markdown; ?>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/blog/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<div class="grid-item main-grid" id="interior-page">

    <div class="header">
    <h1>Page Title</h1>
    </div>

    <div class="content-section" id="sect1">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere rem ducimus doloribus laudantium iure? Facilis cum veritatis, consequatur soluta vero officia suscipit cumque repellat, placeat asperiores similique, quia aspernatur molestias.</p>
    </div>

    <br>
    <div class="section-separator"></div>
    
    <div class="content-section" id="sect2">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere rem ducimus doloribus laudantium iure? Facilis cum veritatis, consequatur soluta vero officia suscipit cumque repellat, placeat asperiores similique, quia aspernatur molestias.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere rem ducimus doloribus laudantium iure? Facilis cum veritatis, consequatur soluta vero officia suscipit cumque repellat, placeat asperiores similique, quia aspernatur molestias.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere rem ducimus doloribus laudantium iure? Facilis cum veritatis, consequatur soluta vero officia suscipit cumque repellat, placeat asperiores similique, quia aspernatur molestias.</p>

    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere rem ducimus doloribus laudantium iure? Facilis cum veritatis, consequatur soluta vero officia suscipit cumque repellat, placeat asperiores similique, quia aspernatur molestias.</p>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/services.blade.php ENDPATH**/ ?>
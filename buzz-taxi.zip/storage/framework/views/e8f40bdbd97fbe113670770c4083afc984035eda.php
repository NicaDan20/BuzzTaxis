

<?php $__env->startSection('content'); ?>

<div class="bookings">
    <table class="bookings-table">
        <tr>
            <th>id</th>
            <th>Full Name</th>
            <th># of people</th>
            <th>Pickup Date</th>
            <th>Phone Number</th>
            <th>Email Address</th>
            <th>Pickup Address</th>
            <th>Destination Address</th>
            <th>Status</th>     
        </tr>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td><?php echo e($booking->id); ?></td>
            <td><?php echo e($booking->name); ?></td>
            <td><?php echo e($booking->nr_people); ?></td>
            <td><?php echo e($booking->date); ?></td>
            <td><?php echo e($booking->phone); ?></td>
            <td><?php echo e($booking->email); ?></td>
            <td><?php echo e($booking->pickup); ?></td>
            <td><?php echo e($booking->destination); ?></td>
            <form action="/booking/<?php echo e($booking->id); ?>"method="POST">
                <?php echo csrf_field(); ?>
                <td><button type="submit" class="delete-post">Remove Booking</button></td>
            </form>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/admin/bookings.blade.php ENDPATH**/ ?>
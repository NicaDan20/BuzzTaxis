<h2>Hello!</h2>
You have received a car booking from: <strong>{{ $name }}</strong>
<br>
Here are the details:
<br>
<b>Name:</b> {{ $name }}
<br>
<b>Email:</b> {{ $email }}
<br>
<b>Phone Number:</b> {{ $phone }}
<br>
<b>From:</b> {{ $pickup }}
<br>
<b>To:</b> {{ $destination }}
<br>
<b>Number of people:</b> {{ $nr_people }}
<br>
<b>Date:</b> {{ $date }}


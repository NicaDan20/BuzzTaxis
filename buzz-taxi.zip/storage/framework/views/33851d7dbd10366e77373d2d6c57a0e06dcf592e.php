<h2>Hello!</h2>
You received an email from: <strong><?php echo e($name); ?></strong>
<br>
Here are the details:
<br>
<b>Name:</b> <?php echo e($name); ?>

<br>
<b>Email:</b> <?php echo e($email); ?>

<br>
<b>Phone Number:</b> <?php echo e($phone); ?>

<br>
<b>Message:</b> <?php echo $user_message; ?>

<?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/email-receive.blade.php ENDPATH**/ ?>
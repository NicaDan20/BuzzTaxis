<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/style.css')); ?>">
    <!-- other css go here, responsive last -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset ('css/responsive.css')); ?>">
    <!-- Scripts -->
    <script src="js/script.js" defer></script>
    <script src="https://kit.fontawesome.com/a756baa22f.js" crossorigin="anonymous"></script>
    <title>Buzz Taxis</title>
</head>
<body class>

    <nav>
        <div class="navigation-mobile">
            <div class="logo-mobile-menu">
                <h1>Logo</h1>
            </div>    
            <div class="navigation-links" id="mobile">
                <ul class="nav-ul">
                    <li><a href="/">Home</a></li>
                    <li><a href="/services">Services</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><button class="button-large" id="telephone"><i class="fa-solid fa-phone-volume black"></i> Call Us  0741023144</button></li>
                </ul>    
            </div>
            <div class="socials-mobile-container">
                <h1>Follow our Socials</h1>
                <ul class="socials-mobile">
                    <li><a href="#"><i class="fa-brands fa-square-facebook"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-square-instagram"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-square-x-twitter"></i></a>
                </ul>   
            </div>    
        </div>    
    </nav>


    <div class="grid-container">

        <div class="grid-item header">
            <nav class="navigation-bar">
                <div class="logo">
                    <h1>Logo</h1>
                </div>
                <a href="#" class="nav-toggle"><i class="fa-solid fa-bars"></i></a>
                 <div class="navigation-links">
                    <ul class="nav-ul">
                        <li><a href="/">Home</a></li>
                        <li><a href="/services">Services</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Careers</a></li>
                    </ul>    
                </div>     
                <div class="telephone">
                    <button class="button-large" id="telephone"><i class="fa-solid fa-phone-volume black"></i> Call Us  0741023144</button>
                </div>
            </nav>
            
        </div>
        

        <div class="grid-item main-grid">
            


            <div class="content-banner">
                <h1>We're taking you the extra mile</h1>
            </div>

            <div class="content-section">
                <h1>High Quality Yeovil Taxi Services</h1>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Deleniti nemo, iste voluptatum delectus obcaecati eos. Qui minus aliquam, impedit beatae atque eum eius tempore corporis praesentium omnis ducimus ad consequatur!</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, natus repellendus iste nisi necessitatibus deleniti officia reprehenderit aliquam dolores veniam pariatur quas ipsam expedita possimus explicabo dolor sequi maiores cupiditate.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, natus repellendus iste nisi necessitatibus deleniti officia reprehenderit aliquam dolores veniam pariatur quas ipsam expedita possimus explicabo dolor sequi maiores cupiditate.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, natus repellendus iste nisi necessitatibus deleniti officia reprehenderit aliquam dolores veniam pariatur quas ipsam expedita possimus explicabo dolor sequi maiores cupiditate.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, natus repellendus iste nisi necessitatibus deleniti officia reprehenderit aliquam dolores veniam pariatur quas ipsam expedita possimus explicabo dolor sequi maiores cupiditate.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, natus repellendus iste nisi necessitatibus deleniti officia reprehenderit aliquam dolores veniam pariatur quas ipsam expedita possimus explicabo dolor sequi maiores cupiditate.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, natus repellendus iste nisi necessitatibus deleniti officia reprehenderit aliquam dolores veniam pariatur quas ipsam expedita possimus explicabo dolor sequi maiores cupiditate.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, natus repellendus iste nisi necessitatibus deleniti officia reprehenderit aliquam dolores veniam pariatur quas ipsam expedita possimus explicabo dolor sequi maiores cupiditate.</p>
            </div>

            <div class="content-sidebar">
                <h1>Book a Cab!</h1>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Repellendus laborum corporis suscipit animi? Et autem vitae molestiae nulla dolorum? Distinctio, similique? Dolorum necessitatibus quas quos molestias iure dolore corporis repudiandae!</p>
                <form action="">
                    <div class="input-wrap">
                        <i class="fa-solid fa-user" id="form-icon"></i>
                        <input class="form-control" type="text" id="col-full" name="name" placeholder="Your Name*" required></span>
                    </div>
                    <div class="input-wrap">
                        <i class="fa-solid fa-person" id="form-icon"></i>
                        <input class="form-control" type="text" id="col-full" name="number" placeholder="Number of People*" required>
                    </div>
                    <div class="input-wrap">
                        <i class="fa-solid fa-calendar-days" id="form-icon"></i>
                        <input class="form-control" type="text" id="col-full" name="date" placeholder="Date*" required>
                    </div>
                    <div class="input-wrap">
                        <i class="fa-solid fa-phone" id="form-icon"></i>
                        <input class="form-control" type="text" id="col-full" name="phone" placeholder="Phone Number*" required>
                    </div>
                    <div class="input-wrap">
                        <i class="fa-solid fa-envelope" id="form-icon"></i>
                        <input class="form-control" type="text" id="col-full" name="email" placeholder="Your Email">
                    </div>
                    <div class="input-wrap">
                        <i class="fa-solid fa-location-dot" id="form-icon"></i>
                        <input class="form-control" type="text" id="col-full" name="pickup" placeholder="Pickup Address*" required>
                    </div>
                    <div class="input-wrap">
                        <i class="fa-solid fa-location-dot" id="form-icon"></i>
                        <input class="form-control" type="text" id="col-full" name="destination" placeholder="Destination Address*" required>
                    </div>
                    <div class="input-wrap">
                        <button class="button-large" id="form-submit" type="submit">Book Now!</button>
                    </div>
                </form>
            </div>

            <br>
            <div class="section-separator"></div>

            <div class="content-testimonials">
                <h1>Testimonials</h1>
            </div>

        </div>

        <!-- ----- Footer Begins ----- --> 

<div class="grid-item footer">

    <!-- Links section -->

    <div class="footer-links" id="col1">
        <h2>Useful Links</h2>
        <ul>
            <li><a href="#">Link 1</a></li>
            <li><a href="#">Link 2</a></li>
            <li><a href="#">Link 3</a></li>
            <li><a href="#">Link 4</a></li>
        </ul>
    </div>

    <div class="footer-links" id="col2">
        <h2>Our Socials</h2>
        <ul>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Instagram</a></li>
            <li><a href="#">LinkedIn</a></li>
        </ul>
    </div>

    <!-- Copyright Section -->

    <div class="copyrights">
        Copyright © 2023 Buzz Taxis | All Rights Reserved | Terms of Use <br>
        Sitemap
    </div>

</div>


    </div>
</body>
</html><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/home2.blade.php ENDPATH**/ ?>
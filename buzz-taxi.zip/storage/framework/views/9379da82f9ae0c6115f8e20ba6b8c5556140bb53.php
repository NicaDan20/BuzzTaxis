

<?php $__env->startSection('content'); ?>
    <div class="blog-main-container">

        <div class="article-container">
            <div class="blog-title">
                <h1>Our Blog</h1>
                <p>Here we share our thoughts on the industry, on our business and what we have been up to recently. Expect monthly or bi-monthly updates.</p>
            </div>

            <?php if(Auth::check()): ?>
                <a href="/blog/create">Create Post</a>
            <?php endif; ?>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="article">
                <div class="article-image-container">
                    <img class="preview-image blog-image " src="<?php echo e($post->image_path); ?>">
                </div>
                <div class="article-title">
                    <h1><?php echo e($post->title); ?></h1>
                </div>
                <div class="article-metadata">
                    <span> <i class="fa-solid fa-user"></i> <?php echo e($post->user->name); ?> &nbsp / &nbsp &nbsp<i class="fa-regular fa-calendar-days"></i> <?php echo e(date('jS M Y', strtotime($post->updated_at))); ?> </span>
                </div>
                <div class="article-description">
                    <p><?php echo $post->description; ?></p>
                </div>
                <div class="read-more large">
                    <a href="/blog/<?php echo e($post->slug); ?>">Read More</a>
                </div>
            </div>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        </div>

        
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/blog/index.blade.php ENDPATH**/ ?>
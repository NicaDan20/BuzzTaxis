<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name= “robots” content=index, follow>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="keywords" content="yeovil taxi, taxi, taxi yeovil, airport transport yeovil, airport transport, yeovil taxi"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/blog.css')); ?>">

    <!-- other css go here, responsive last -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/responsive.css')); ?>">
    <!-- Scripts -->
    <script src="/js/script.js" defer></script>
    <script src="/js/animate.js" defer></script>
    <script src="/js/geo.js" defer></script>
    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6fCGEZswLfa3ALmvgHJnWVTv7_NT5dUA&libraries=places&callback=initAutocomplete"
        defer></script>
    <script src="https://kit.fontawesome.com/a756baa22f.js" crossorigin="anonymous"></script>

    <?php echo htmlScriptTagJsApi(); ?>


</head>

<body class>
    <div class="loader-wrapper">
        <div class="cs-loader-inner">
            <label>●</label>
            <label>●</label>
            <label>●</label>
            <label>●</label>
            <label>●</label>
            <label>●</label>
        </div>
    </div>
    <?php echo $__env->make('inc.navbar-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="grid-container">
        <?php echo $__env->make('inc.navbar-desktop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <script>
        let loader = document.getElementsByClassName('loader-wrapper')[0];
        window.addEventListener("load", function() {
            loader.style.display = "none";
        });

        function onSubmit(token) {
        document.getElementById("book-form").submit();
        }

    </script>
</body>

</html>
<?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/layouts/posts.blade.php ENDPATH**/ ?>
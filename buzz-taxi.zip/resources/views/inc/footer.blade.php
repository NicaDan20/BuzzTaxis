@section ('footer')

<!-- ----- Footer Begins ----- --> 

<div class="grid-item footer">

    <!-- Links section -->

    <div class="footer-links" id="col1">
        <h2>Useful Links</h2>
        <ul>
            <li><a href="#">Link 1</a></li>
            <li><a href="#">Link 2</a></li>
            <li><a href="#">Link 3</a></li>
            <li><a href="#">Link 4</a></li>
        </ul>
    </div>

    <div class="footer-links" id="col2">
        <h2>Our Socials</h2>
        <ul>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Instagram</a></li>
            <li><a href="#">LinkedIn</a></li>
        </ul>
    </div>

    <!-- Copyright Section -->

    <div class="copyrights">
        Copyright © 2023 Buzz Taxis | All Rights Reserved | <a href="/terms-of-use">Terms of Use</a> <br>
        Sitemap
    </div>

</div>

<!-- ----- Footer Ends ----- --> 

<h2>Hello!</h2>
You received an email from: <strong>{{ $name }}</strong>
<br>
Here are the details:
<br>
<b>Name:</b> {{ $name }}
<br>
<b>Email:</b> {{ $email }}
<br>
<b>Phone Number:</b> {{ $phone }}
<br>
<b>Message:</b> {!! $user_message !!}

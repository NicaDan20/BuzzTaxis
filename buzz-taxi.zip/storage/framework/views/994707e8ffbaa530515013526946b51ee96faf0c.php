<?php $__env->startSection('navbar'); ?>

<!-- ----- Navbar Begins ------- -->

<!-- --- Mobile Navbar Begins --- -->
<header>
    <nav>
        <div class="navigation-mobile">
            <div class="logo-mobile-menu">
                <h1>Logo</h1>
            </div>    
            <div class="navigation-links" id="mobile">
                <ul class="nav-ul">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><button class="button-large" id="telephone"><i class="fa-solid fa-phone-volume black"></i> Call Us  0741023144</button></li>
                </ul>    
            </div>
            <div class="socials-mobile-container">
                <h1>Follow our Socials</h1>
                <ul class="socials-mobile">
                    <li><a href="#"><i class="fa-brands fa-square-facebook"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-square-instagram"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-square-x-twitter"></i></a>
                </ul>   
            </div>    
        </div>    
    </nav>
<!-- --- Mobile Navbar Ends --- -->    

<!-- Desktop Navbar Begins --- -->
    <div class="grid-container">
        <div class="grid-item header">
            <nav class="navigation-bar">
                <div class="logo">
                    <h1>Logo</h1>
                </div>
                <a href="#" class="nav-toggle"><i class="fa-solid fa-bars"></i></a>
                 <div class="navigation-links">
                    <ul class="nav-ul">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Services</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Careers</a></li>
                    </ul>    
                </div>     
                <div class="telephone">
                    <button class="button-large" id="telephone"><i class="fa-solid fa-phone-volume black"></i> Call Us  0741023144</button>
                </div>
            </nav>
            
        </div>
<!-- Desktop Navbar Ends --- -->
        <header>
<!-- ----- Navbar Ends ------- -->

<?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/inc/navbar.blade.php ENDPATH**/ ?>
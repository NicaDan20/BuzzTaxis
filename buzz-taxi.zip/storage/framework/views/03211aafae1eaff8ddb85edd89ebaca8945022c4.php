

<?php $__env->startSection('content'); ?>
    <div class="blog-main-container">
        <div class="article-container">
            <div class="blog-title">
                <h1>Hello</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis, eius! Quibusdam aut cum, quisquam ipsam sunt dolore optio sint omnis? Earum expedita possimus vel molestias iste voluptatum unde maxime similique?</p>
            </div>
            <div class="article">
                <div class="article-image-container">
                    <img class="preview-image blog-image " src="/images/logo/logo_business-card.jpg">
                </div>
                <div class="article-title">
                    <h1>Title</h1>
                </div>
                <div class="article-metadata">
                    <span> <i class="fa-solid fa-user"></i> Author 1 &nbsp / &nbsp &nbsp<i class="fa-regular fa-calendar-days"></i> Date 1 </span>
                </div>
                <div class="article-description">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae, a. Quidem hic illum incidunt voluptates similique obcaecati magni veritatis quia, itaque earum iusto optio ut at quo quis maiores expedita?
                </div>
                <div class="read-more large">
                    <a href="#">Read More</a>
                </div>
            </div>    

            <div class="article">
                <div class="article-image-container">
                    <img class="preview-image blog-image " src="/images/logo/logo_business-card.jpg">
                </div>
                <div class="article-title">
                    Title
                </div>
                <div class="article-metadata">
                    <span> <i class="fa-solid fa-user"></i> Author 1 &nbsp / &nbsp &nbsp<i class="fa-regular fa-calendar-days"></i> Date 1 </span>
                </div>
                <div class="article-description">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae, a. Quidem hic illum incidunt voluptates similique obcaecati magni veritatis quia, itaque earum iusto optio ut at quo quis maiores expedita?
                </div>
                <div class="read-more large">
                    <a href="#">Read More</a>
                </div>
            </div>    

            <div class="article">
                <div class="article-image-container">
                    <img class="preview-image blog-image " src="/images/logo/logo_business-card.jpg">
                </div>
                <div class="article-title">
                    Title
                </div>
                <div class="article-metadata">
                    <span> <i class="fa-solid fa-user"></i> Author 1 &nbsp / &nbsp &nbsp<i class="fa-regular fa-calendar-days"></i> Date 1 </span>
                </div>
                <div class="article-description">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae, a. Quidem hic illum incidunt voluptates similique obcaecati magni veritatis quia, itaque earum iusto optio ut at quo quis maiores expedita?
                </div>
                <div class="read-more large">
                    <a href="#">Read More</a>
                </div>
            </div>    

            <div class="article">
                <div class="article-image-container">
                    <img class="preview-image blog-image " src="/images/logo/logo_business-card.jpg">
                </div>
                <div class="article-title">
                    Title
                </div>
                <div class="article-metadata">
                    Author / Date
                </div>
                <div class="article-description">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae, a. Quidem hic illum incidunt voluptates similique obcaecati magni veritatis quia, itaque earum iusto optio ut at quo quis maiores expedita?</p>
                </div>
                <div class="read-more large">
                    <a href="#">Read More</a>
                </div>
            </div>    

        </div>

        
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/blog.blade.php ENDPATH**/ ?>
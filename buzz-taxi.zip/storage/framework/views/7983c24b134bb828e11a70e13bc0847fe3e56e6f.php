

<?php $__env->startSection('content'); ?>


<?php if(Auth::check()): ?>
    <a href="/blog/create">Create Post</a>
<?php endif; ?>

<?php if(session()-> has('message')): ?> 
<div class="message">
    <p>
        <?php echo e(session()->get('message')); ?>

    </p>
</div>

<?php endif; ?>


<div class="posts">
    <ul class="posts-list">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="/blog/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a> -- By <?php echo e($post->user->name); ?> -- Last updated on: <?php echo e($post->updated_at); ?> --                     <span>
            <a href="/blog/<?php echo e($post->slug); ?>/edit">Edit</a>
            <form class="delete-post" action="/blog/<?php echo e($post->slug); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>

                <button class="delete-post" type="submit">Delete</button>
            </form>
        </span>
</li>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?>


    </ul>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/admin/posts.blade.php ENDPATH**/ ?>
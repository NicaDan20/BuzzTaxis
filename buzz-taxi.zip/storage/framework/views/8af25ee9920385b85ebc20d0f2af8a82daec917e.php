

<?php $__env->startSection('latest-posts'); ?>

<div class="section-title">
    <h1>Latest Posts</h1>
</div>
<div class="posts-container">
    <div class="post-box">
        <div class="preview-image-container">
            <img class="preview-image" src="/images/logo/logo_square-removebg.png">
        </div>
        <div class="post-title">
            <h6>Title 1</h6>
        </div>

        <div class="post-metadata">
            <div class="post-author">
                <p>Author 1</p>
            </div>
            <div class="post-date">
                <p>Date 1</p>
            </div>
        </div>

        <div class="preview-text">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla dalar makronio asparagisticar temelion aspartoekeriallasirsa mastodonti.</p>
        </div>

        <div class="Read-more">
            <a href="#">Read More</a>
        </div>

    </div>

    <div class="post-box">
        <div class="preview-image-container">
            <img class="preview-image" src="/images/logo/logo_square-removebg.png">
        </div>
        <div class="post-title">
            <h6>Title 1</h6>
        </div>

        <div class="post-metadata">
            <div class="post-author">
                <p>Author 1</p>
            </div>
            <div class="post-date">
                <p>Date 1</p>
            </div>
        </div>

        <div class="preview-text">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla dalar makronio asparagisticar temelion aspartoekeriallasirsa mastodonti.</p>
        </div>

        <div class="Read-more">
            <a href="#">Read More</a>
        </div>

    </div>


    <div class="post-box">
        <div class="preview-image-container">
            <img class="preview-image" src="/images/logo/logo_square-removebg.png">
        </div>
        <div class="post-title">
            <h6>Title 1</h6>
        </div>

        <div class="post-metadata">
            <div class="post-author">
                <p>Author 1</p>
            </div>
            <div class="post-date">
                <p>Date 1</p>
            </div>
        </div>

        <div class="preview-text">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla dalar makronio asparagisticar temelion aspartoekeriallasirsa mastodonti.</p>
        </div>

        <div class="Read-more">
            <a href="#">Read More</a>
        </div>

    </div>

    <div class="post-box">
        <div class="preview-image-container">
            <img class="preview-image" src="/images/logo/logo_square-removebg.png">
        </div>
        <div class="post-title">
            <h6>Title 1</h6>
        </div>

        <div class="post-metadata">
            <div class="post-author">
                <p>Author 1</p>
            </div>
            <div class="post-date">
                <p>Date 1</p>
            </div>
        </div>

        <div class="preview-text">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla dalar makronio asparagisticar temelion aspartoekeriallasirsa mastodonti.</p>
        </div>

        <div class="Read-more">
            <a href="#">Read More</a>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\Website Taxi\BuzzTaxis\resources\views/inc/latest-posts.blade.php ENDPATH**/ ?>